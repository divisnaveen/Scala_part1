activator-akka-scala-seed
=========================

Toy Ping-Pong Actor demo based on one of the Lightbend Activator seed
projects.  Activator is generally a quick and easy way to spit out the
skeleton for an SBT project, for various project types, that one can use
to build upon.


