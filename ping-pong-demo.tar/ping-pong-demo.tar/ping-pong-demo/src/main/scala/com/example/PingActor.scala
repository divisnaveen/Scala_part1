package com.example

import akka.actor.{Actor, ActorLogging, Props}

/**
  * The PingActor for our Ping-Pong demo.
  */

//
// It is customary to define the messages that an Actor traffics in as
// case classes defined in the Actor's companion object.
//
object PingActor {
  // NOTE It's convenient to capture the Props for a given actor type in an
  // immutable field in the actor's companion object to enable easy creation.
  val props = Props[PingActor]

  // NOTE It's a good practice to define the Messages defined by the PingActor
  // in its companion object. If a message has no parametrization then it can
  // be a singleton case object, otherwise it should be a case class, capturing
  // its properties in its primary constructor. Making the messages case
  // objects or case classes is needed because we'll want to pattern match on
  // them in the receive methods via which they enter running actors for
  // processing.
  case object Initialize
  case class PingMessage(text: String)
}


class PingActor extends Actor with ActorLogging {
  import PingActor._

  // When this actor is born we set a counter to zero...
  var counter = 0   // NOTE State mutable but entirely hidden inside this actor!

  // ...and we create a child actor to talk to, the Pong to our Ping.
  // NOTE we use the Props object that we secreted away in the companion object
  // for the actor we want to create.
  val pongActor = context.actorOf(PongActor.props, "pongActor")

  // NOTE The receive method for an actor is a PartialFunction[Any, Unit] that
  // defines the initial behavior of the actor.  We will see later that
  // behaviors can change over the course of an actor's lifetime.
  //
  // The receive PartialFunction contains the logic that the actor executes
  // when it receives messages.
  def receive = {

    case Initialize =>
      log.info("In PingActor - starting ping-pong")   // Log what we're doing
      pongActor ! PingMessage("ping")                 // Send a ping to our pong

    case PongActor.PongMessage(text) =>
      log.info("In PingActor - received message: {}", text)
      counter += 1                                    // Count the received pong
      if (counter == 3) context.system.terminate()    // Shut down actor system
      else sender() ! PingMessage("ping")             // Reply to pong with ping

  }
}

//
// NOTE
// What the heck is that 'context' thing up above in the PingActor's receive?
//
// The context for the actor includes, among other things:
//
//    1. an ActorRef for the actor itself, called 'self'
//
//    2. an ActorRef to the sender of the message we're currently processing,
//       called 'sender'.
//
//    3. The ActorSystem that our actor is part of, accessible via 'system'
//       WARNING: The ActorSystem reference is only valid within this Actor
//                itself, so you must not leak it beyond the scope of this
//                actor.  Common accidental ways of creating such leaks include
//                closing over the ActorSystem in a closure or explicitly
//                publishing it to another thread by storing it in a shared
//                variable.
