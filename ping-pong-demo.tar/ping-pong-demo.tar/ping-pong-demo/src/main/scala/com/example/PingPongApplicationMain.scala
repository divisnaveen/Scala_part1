package com.example

import java.util.concurrent.TimeUnit

import akka.actor.ActorSystem

import scala.concurrent.Await
import scala.concurrent.duration.Duration

/**
  * NOTE We use the App trait to quickly turn an object into an executable
  * program.
  *
  * Below, object PingPongApplicationMain inherits the main method of App.
  * args would return the current command line arguments as an array.
  * The whole class body becomes the “main method”.
  */
object PingPongApplicationMain extends App {

  // Create an ActorSystem for our application...
  val system = ActorSystem("PingPongActorSystem")

  // Ask the actor system to create a new actor as child of this context with
  // the given name and grab its ActorRef.
  val pingActor = system.actorOf(PingActor.props,   // Props for PingActor
                                 "pingActor")       // Name for new actor

  // Send a message using 'tell' to the actor behind the ActorRef
  pingActor ! PingActor.Initialize
  // This example app will ping pong 3 times and thereafter terminate
  // the ActorSystem - see counter logic in PingActor

  // system.whenTerminated returns a Future which will be completed after the
  // ActorSystem has been terminated and termination hooks have been executed.
  //
  // We call Await to block and wait on the "completed" state of an Awaitable,
  // namely the system.whenTerminated Future, with the given timeout.
  Await.ready(system.whenTerminated, Duration(1, TimeUnit.MINUTES))
}
