package com.example

import akka.actor.ActorSystem
import akka.actor.Actor
import akka.actor.Props
import akka.testkit.{ TestActors, TestKit, ImplicitSender }
import org.scalatest.WordSpecLike
import org.scalatest.Matchers
import org.scalatest.BeforeAndAfterAll

/**
  * We extend the TestKit class from akka.testkit to create a unit test suite.
  * Inheriting from TestKit lets our test receive replies from actors.
  * Replies from actors are queued by an actor internal to TestKit and
  * can be examined and asserted again using the 'expectMsg' family of methods.
  *
  * The assertions support also lets us put bounds on the timing of message
  * receipts.
  *
  * A few things to remember:
  *
  *   1. The ActorSystem passed into the constructor of the test needs to be
  *      shutdown, otherwise we can leak memory, and thread pools.
  *
  *   2. TestKit is not thread-safe. It is expected that your test cases will
  *      run in the constructor, as shown here.  If you don't do that, one
  *      has to be careful not to run tests within a single test class in
  *      parallel.
  *
  * We'll study TestKit and the testing of Actors in more detail later in
  * the course.  For now, understanding the example below should be enough
  * to get started.
  *
  * @param _system ActorSystem under which to run the test suite.
  */
class PingPongActorSpec(_system: ActorSystem) extends TestKit(_system)
                                              with ImplicitSender
                                              with WordSpecLike // BDD-ish stuff
                                              with Matchers     // Asserts DSL
                                              with BeforeAndAfterAll {

  // Auxiliary constructor that creates an actor system for our use
  def this() = this(ActorSystem("PingPongSpec"))

  // Method to run after all of this suite's tests have run.
  override def afterAll {
    TestKit.shutdownActorSystem(system)
  }

  // Test cases, written in BDD fluent style
  "A Ping actor" must {
    "send back a ping on a pong" in {
      val pingActor = system.actorOf(PingActor.props)
      pingActor ! PongActor.PongMessage("pong")
      expectMsg(PingActor.PingMessage("ping"))
    }
  }

  "A Pong actor" must {
    "send back a pong on a ping" in {
      val pongActor = system.actorOf(PongActor.props)
      pongActor ! PingActor.PingMessage("ping")
      expectMsg(PongActor.PongMessage("pong"))
    }
  }

}
