package com.example

import akka.actor.{Actor, ActorLogging, Props}

/**
  * The PongActor for our Ping-Pong demo.
  */

//
// As before we stash away the Props we use for creating a PongActor, as well
// as the messages the PongActor defines, in the PongActor's companion object.
//
object PongActor {
  val props = Props[PongActor]

  // Messages
  case class PongMessage(text: String)
}

class PongActor extends Actor with ActorLogging {
  import PongActor._

  // Here's PongActor's receive, i.e. a PartialFunction[Any, Unit], that
  // implements its starting behavior / message processing logic.
  def receive = {

  	case PingActor.PingMessage(text) => 
  	  log.info("In PongActor - received message: {}", text)
  	  sender() ! PongMessage("pong")

  }
}
